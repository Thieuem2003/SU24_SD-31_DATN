package com.backend.service;

public interface IEmailTemplateService {
}
