package com.backend.service.impl;

//import com.backend.dto.request.AccountRequest;
//import com.backend.dto.request.RegisterRequest;
//import com.backend.dto.request.account.AccountAddress;
//import com.backend.dto.response.AccountPageResponse;
//import com.backend.dto.response.AccountResponse;
//import com.backend.dto.response.RegisterResponse;
//import com.backend.entity.Account;
//import com.backend.repository.AccountRepository;
//import com.backend.repository.AddressRepository;
//import com.backend.repository.RoleRepository;
//import com.backend.service.IAccountService;
//import com.backend.service.ImageUploadService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Service
public class AccountServiceImpl  {

//    @Autowired
//    private AccountRepository accountRepository;
//
//    @Autowired
//    private RoleRepository roleRepository;
//
//    @Autowired
//    private AddressRepository addressRepository;
//
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    private ImageUploadService imageUploadService;


}
