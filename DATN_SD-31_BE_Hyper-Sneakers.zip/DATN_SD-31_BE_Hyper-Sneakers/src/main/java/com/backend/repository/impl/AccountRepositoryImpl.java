package com.backend.repository.impl;

public class AccountRepositoryImpl {
}
