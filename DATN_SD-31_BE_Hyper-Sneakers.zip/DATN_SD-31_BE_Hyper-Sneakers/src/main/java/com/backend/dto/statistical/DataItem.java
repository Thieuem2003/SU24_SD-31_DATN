package com.backend.dto.statistical;

public class DataItem {
}
