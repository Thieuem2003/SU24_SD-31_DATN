package com.backend.dto.response;

public class AccountPageResponse {
}
